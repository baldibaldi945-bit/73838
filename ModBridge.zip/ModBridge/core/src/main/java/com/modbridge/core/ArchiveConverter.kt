package com.modbridge.core

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.LinkedHashMap
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Offline archive pipeline. Missing optional assets never abort conversion. */
object ArchiveConverter {
    data class Result(
        val bytes: ByteArray,
        val source: String,
        val files: Int,
        val charts: Int,
        val warnings: List<String>,
        val runtimeFiles: Int = 0,
        val scriptsTranslated: Int = 0,
        val sourceFilesExcluded: Int = 0
    )

    private const val MAX_ENTRY = 192 * 1024 * 1024
    private const val MAX_TOTAL = 1024L * 1024 * 1024

    /**
     * includeSourceBackup=false means unsupported source-only content is removed from the playable
     * output. Turn it on only when the user explicitly wants a recovery copy.
     */
    fun convert(input: ByteArray, includeSourceBackup: Boolean = false, optimizeShaders: Boolean = true, sourceName: String? = null): Result {
        val files = LinkedHashMap<String, ByteArray>()
        val warnings = mutableListOf<String>()
        var total = 0L

        fun unpack(bytes: ByteArray, prefix: String = "", depth: Int = 0) {
            require(depth <= 4) { "Nested archive depth exceeded" }
            ZipInputStream(ByteArrayInputStream(bytes)).use { zin ->
                while (true) {
                    val entry = zin.nextEntry ?: break
                    val raw = entry.name.replace('\\', '/')
                    if (entry.isDirectory || raw.startsWith("/") || raw.split('/').any { it == ".." }) {
                        zin.closeEntry(); continue
                    }
                    val name = (prefix + raw).trimStart('/')
                    val buffer = ByteArrayOutputStream()
                    val chunk = ByteArray(16 * 1024)
                    var entrySize = 0
                    while (true) {
                        val n = zin.read(chunk)
                        if (n < 0) break
                        entrySize += n
                        total += n
                        require(entrySize <= MAX_ENTRY && total <= MAX_TOTAL) { "Archive exceeds safe extraction limits" }
                        buffer.write(chunk, 0, n)
                    }
                    val data = buffer.toByteArray()
                    if (raw.substringAfterLast('.', "").lowercase(Locale.ROOT) == "zip" && depth < 4) {
                        val parent = name.substringBeforeLast('/', "").let { if (it.isBlank()) "" else "$it/" }
                        val base = name.substringAfterLast('/').substringBeforeLast('.')
                        val first = runCatching {
                            ZipInputStream(ByteArrayInputStream(data)).use { it.nextEntry?.name?.replace('\\', '/') ?: "" }
                        }.getOrDefault("")
                        val nestedPrefix = if (first.startsWith("$base/")) parent else "$parent$base/"
                        val before = files.size
                        runCatching { unpack(data, nestedPrefix, depth + 1) }
                            .onFailure { files[name] = data; warnings += "تعذر فك الأرشيف الداخلي: $name (${it.message ?: "unknown"})" }
                        if (files.size == before && name !in files && first.isBlank()) {
                            files[name] = data
                            warnings += "أرشيف داخلي فارغ أو غير صالح: $name"
                        }
                    } else {
                        files[name] = data
                    }
                    zin.closeEntry()
                }
            }
        }

        unpack(input)
        val normalized = stripCommonRoot(files)
        val source = detect(normalized)
        val out = LinkedHashMap<String, ByteArray>()
        var charts = 0
        when (source) {
            "Codename Engine" -> charts += CodenameConverter.convert(normalized, out, warnings)
            "V-Slice" -> charts += VSliceConverter.convert(normalized, out, warnings)
            "Funky Maker Mobile" -> charts += FnmmConverter.convert(normalized, out, warnings, sourceName)
            else -> warnings += "لم أتعرف على صيغة المصدر. حُفظت الأصول المعروفة فقط؛ تحقق من اختيار ملف ZIP الصحيح."
        }

        // Shared runtime assets; none is mandatory for chart conversion.
        copyRuntimeAssets(normalized, out, source, warnings)

        // Offline AI-assisted script migration: translate only recognized, safe HScript patterns.
        var translatedScripts = 0
        var skippedScriptFiles = 0
        for ((path, bytes) in normalized) {
            val ext = path.substringAfterLast('.', "").lowercase(Locale.ROOT)
            if (ext !in setOf("hx", "hscript", "hxs", "hxc")) continue
            val translation = runCatching { ScriptMigrationAI.translate(bytes.toString(Charsets.UTF_8)) }.getOrNull()
            if (translation == null) {
                skippedScriptFiles++
                continue
            }
            val stem = safeName(path.substringAfterLast('/').substringBeforeLast('.'))
            val songName = Regex("(?:^|/)(?:data/)?songs/([^/]+)/(?:scripts/)?", RegexOption.IGNORE_CASE).find(path)?.groupValues?.get(1)
                ?: Regex("(?:^|/)scripts/songs/([^/]+)/", RegexOption.IGNORE_CASE).find(path)?.groupValues?.get(1)
            val stageName = Regex("(?:^|/)(?:data/)?stages/([^/]+)\\.(?:hx|hscript|hxs|hxc)$", RegexOption.IGNORE_CASE).find(path)?.groupValues?.get(1)
                ?: Regex("(?:^|/)scripts/stages/([^/]+)\\.(?:hx|hscript|hxs|hxc)$", RegexOption.IGNORE_CASE).find(path)?.groupValues?.get(1)
            val eventName = Regex("(?:^|/)(?:data/)?events/([^/]+)\\.(?:hx|hscript|hxs|hxc)$", RegexOption.IGNORE_CASE).find(path)?.groupValues?.get(1)
                ?: Regex("(?:^|/)scripts/events/([^/]+)\\.(?:hx|hscript|hxs|hxc)$", RegexOption.IGNORE_CASE).find(path)?.groupValues?.get(1)
            val notetypeName = Regex("(?:^|/)(?:data/)?notetypes/([^/]+)\\.(?:hx|hscript|hxs|hxc)$", RegexOption.IGNORE_CASE).find(path)?.groupValues?.get(1)
            val target = when {
                songName != null -> "data/${safeName(songName)}/script.lua"
                stageName != null -> "stages/${safeName(stageName)}.lua"
                eventName != null -> "custom_events/${safeName(eventName)}.lua"
                notetypeName != null -> "custom_notetypes/${safeName(notetypeName)}.lua"
                else -> "scripts/mb_${stem}.lua"
            }
            val existing = out[target]?.toString(Charsets.UTF_8)
            val newLua = if (existing.isNullOrBlank()) translation.lua else mergeLuaCallbacks(existing, translation.lua)
            out[target] = utf(newLua)
            translatedScripts++
            warnings += "AI محلي: $path → $target (${translation.recognized} تعليمات معروفة: ${translation.recognizedFeatures.joinToString()})."
            if (translation.skipped > 0) warnings += "AI محلي: تخطّى ${translation.skipped} تعبيرات غير مدعومة في $path دون تنفيذها."
        }
        if (skippedScriptFiles > 0) warnings += "$skippedScriptFiles ملفات سكربت لم أجد فيها تعليمات آمنة قابلة للتحويل؛ أُزيلت من ملفات التشغيل."

        // Shader files are kept only when referenced by generated runtime Lua, and are minified
        // conservatively (comments/extra whitespace only; no shader maths or loop counts changed).
        val shaderRefs = out.filterKeys { it.endsWith(".lua", true) }.values
            .flatMap { Regex("(?:initLuaShader|setSpriteShader)\\s*\\(\\s*['\"]([^'\"]+)").findAll(it.toString(Charsets.UTF_8)).map { m -> m.groupValues[1].lowercase(Locale.ROOT) }.toList() }
            .toSet()
        var shaderKept = 0
        var shaderRemoved = 0
        for ((path, bytes) in normalized) {
            val ext = path.substringAfterLast('.', "").lowercase(Locale.ROOT)
            if (ext !in setOf("frag", "vert", "glsl")) continue
            val name = path.substringAfterLast('/').substringBeforeLast('.').lowercase(Locale.ROOT)
            if (!optimizeShaders || name in shaderRefs) {
                val content = bytes.toString(Charsets.UTF_8)
                val optimized = if (optimizeShaders) minifyShader(content) else content
                out["shaders/${path.substringAfterLast('/')}"] = utf(optimized)
                shaderKept++
            } else shaderRemoved++
        }
        if (shaderKept > 0) warnings += "Shaders: kept $shaderKept referenced shader file(s); removed $shaderRemoved unused shader file(s) from runtime."
        else if (shaderRemoved > 0) warnings += "Shaders: removed $shaderRemoved unused/unreferenced shader file(s) from runtime."

        // No soundtrack is mandatory; any included audio was already copied to songs/<id> above.

        // A chart remains exportable without audio. Disable vocal loading when no vocals are present,
        // and make the absence of an instrumental explicit in the report.
        val chartPaths = out.keys.filter { it.startsWith("data/") && it.endsWith(".json", true) }
        for (chartPath in chartPaths) {
            val slug = chartPath.removePrefix("data/").substringBefore('/')
            val song = json(out[chartPath] ?: continue)?.optJSONObject("song") ?: continue
            val songAudioPrefix = "songs/$slug/"
            val audioNames = out.keys.filter { it.startsWith(songAudioPrefix, true) }
            val hasInst = audioNames.any { it.substringAfterLast('/').startsWith("Inst", true) }
            val hasVocals = audioNames.any { it.substringAfterLast('/').startsWith("Voices", true) }
            if (!hasVocals && song.optBoolean("needsVoices", false)) {
                song.put("needsVoices", false)
                out[chartPath] = utf(JSONObject().put("song", song).toString(2))
            }
            if (!hasInst) warnings += "الأغنية '$slug': ملف Inst غير موجود؛ تم إنشاء الشارت بدون صوت ولن يتوقف التحويل."
        }

        var backupCount = 0
        if (includeSourceBackup) {
            for ((path, data) in normalized) {
                out.putIfAbsent("_modbridge_source/$path", data)
                backupCount++
            }
        }
        val excluded = normalized.keys.count { path ->
            val lower = path.lowercase(Locale.ROOT)
            val ext = lower.substringAfterLast('.', "")
            ext in setOf("hx", "hscript", "hxs", "xml", "ini", "frag", "vert", "glsl") ||
                lower.startsWith("data/states/") || lower.startsWith("states/") ||
                lower.endsWith("sprite.json") || lower.endsWith("scene.json") || lower.endsWith("events.json") || lower.endsWith("meta.json")
        }
        val report = buildString {
            appendLine("ModBridge — Psych Engine Conversion Report")
            appendLine("Source engine: $source")
            appendLine("Input files inspected: ${normalized.size}")
            appendLine("Psych charts generated: $charts")
            appendLine("HScript/Haxe files translated by offline AI rules: $translatedScripts")
            appendLine("Unused shaders removed: $shaderRemoved")
            appendLine("Optional source backup included: ${if (includeSourceBackup) "yes" else "no"}")
            appendLine("Runtime output files: ${out.size + 1}")
            appendLine()
            appendLine("Warnings and skipped features:")
            if (warnings.isEmpty()) appendLine("- No structural warnings detected.") else warnings.distinct().forEach { appendLine("- $it") }
            appendLine()
            appendLine("Offline AI limitation: this translator uses deterministic conversion rules and does not invent code. Unrecognized Haxe/Flixel logic is not put into runtime Lua.")
            appendLine("Missing optional music, sprite sheets, stage assets or metadata do not stop conversion. Check the generated Psych mod in your target Psych Engine version.")
        }
        out["conversion-report.txt"] = utf(report)

        val zipped = ByteArrayOutputStream()
        ZipOutputStream(zipped).use { zout ->
            for ((name, data) in out) {
                if (name.startsWith("/") || name.split('/').any { it == ".." }) continue
                zout.putNextEntry(ZipEntry(name))
                zout.write(data)
                zout.closeEntry()
            }
        }
        return Result(zipped.toByteArray(), source, normalized.size, charts, warnings.distinct(), out.size, translatedScripts, excluded)
    }

    private fun copyRuntimeAssets(files: Map<String, ByteArray>, out: MutableMap<String, ByteArray>, source: String, warnings: MutableList<String>) {
        for ((path, bytes) in files) {
            val lower = path.lowercase(Locale.ROOT)
            when {
                lower.startsWith("images/") || lower.startsWith("fonts/") || lower.startsWith("sounds/") -> out.putIfAbsent(path, bytes)
                lower.startsWith("assets/images/") -> out.putIfAbsent(path.removePrefix("assets/"), bytes)
                lower.startsWith("assets/fonts/") -> out.putIfAbsent(path.removePrefix("assets/"), bytes)
                lower.startsWith("assets/sounds/") -> out.putIfAbsent(path.removePrefix("assets/"), bytes)
                isAudio(lower) -> {
                    val parts = path.split('/')
                    val songsIndex = parts.indexOfFirst { it.equals("songs", true) }
                    val song = when {
                        songsIndex >= 0 && parts.size > songsIndex + 1 -> safeName(parts[songsIndex + 1])
                        source == "Funky Maker Mobile" -> out.keys.firstOrNull { it.startsWith("data/") && it.endsWith(".json", true) }
                            ?.removePrefix("data/")?.substringBefore('/') ?: "fnmm-song"
                        else -> parts.getOrNull(parts.size - 2)?.let { safeName(it) } ?: "converted-song"
                    }
                    val original = parts.last()
                    val canonical = when (original.substringBeforeLast('.', "").lowercase(Locale.ROOT)) {
                        "voices", "vocals" -> "Voices"
                        "inst", "instrumental", "music" -> "Inst"
                        else -> original.substringBeforeLast('.')
                    }
                    val ext = original.substringAfterLast('.', "ogg").lowercase(Locale.ROOT)
                    out.putIfAbsent("songs/$song/$canonical.$ext", bytes)
                }
            }
        }
    }

    private fun isAudio(path: String) = path.endsWith(".ogg") || path.endsWith(".mp3") || path.endsWith(".wav") || path.endsWith(".flac")

    private fun minifyShader(source: String): String {
        val withoutBlockComments = source.replace(Regex("/\\*[\\s\\S]*?\\*/"), "")
        val withoutLineComments = withoutBlockComments.lines().joinToString("\n") { it.substringBefore("//") }
        return withoutLineComments.lines().joinToString("\n") { it.trim().replace(Regex("\\s+"), " ") }
            .lines().filter { it.isNotBlank() }.joinToString("\n") + "\n"
    }

    private fun mergeLuaCallbacks(existing: String, incoming: String): String {
        var result = existing
        val functionRegex = Regex("(?s)function\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*\\([^)]*\\)\\s*\\n(.*?)\\nend")
        for (m in functionRegex.findAll(incoming)) {
            val name = m.groupValues[1]
            val body = m.groupValues[2].trim()
            val existingFunction = Regex("(?s)(function\\s+$name\\s*\\([^)]*\\)\\s*\\n)(.*?)(\\nend)")
            val match = existingFunction.find(result)
            result = if (match != null) {
                val merged = match.groupValues[1] + match.groupValues[2].trimEnd() + "\n" + body + match.groupValues[3]
                result.replaceRange(match.range, merged)
            } else result + "\n" + m.value
        }
        return result
    }

    private fun stripCommonRoot(input: Map<String, ByteArray>): Map<String, ByteArray> {
        val keys = input.keys.toList()
        val first = keys.firstOrNull() ?: return input
        val root = first.substringBefore('/', "")
        return if (root.isNotEmpty() && keys.all { it.startsWith("$root/") }) input.mapKeys { it.key.removePrefix("$root/") } else input
    }

    private fun detect(files: Map<String, ByteArray>): String {
        val paths = files.keys.map { it.lowercase(Locale.ROOT) }
        val fnmm = paths.any { it.endsWith("data.json") } || paths.any { it.endsWith("scene.json") } ||
            (paths.any { it.endsWith("events.json") } && paths.any { it.startsWith("sprites/") }) ||
            paths.any { it.startsWith("sprites/") }
        val codename = paths.any { it.contains("/charts/") && it.endsWith(".json") } ||
            paths.any { it == "data/config/modpack.ini" } ||
            paths.any { it.startsWith("data/characters/") && it.endsWith(".xml") } ||
            paths.any { it.startsWith("data/stages/") && it.endsWith(".xml") }
        val vslice = paths.any { it.contains("metadata") && it.endsWith(".json") } || paths.any { it.contains("-chart.json") } || paths.any { it.contains("-chart.") }
        return when {
            fnmm -> "Funky Maker Mobile"
            codename -> "Codename Engine"
            vslice -> "V-Slice"
            else -> "Unknown"
        }
    }
}

internal fun json(bytes: ByteArray): JSONObject? = try { JSONObject(bytes.toString(Charsets.UTF_8)) } catch (_: Throwable) { null }
internal fun utf(value: String) = value.toByteArray(Charsets.UTF_8)
internal fun safeName(value: String) = value.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9_-]+"), "-").trim('-').ifBlank { "song" }

/** Psych Engine section builder, including V-Slice tempo and camera-focus changes. */
internal fun psychChart(
    song: String,
    bpm: Double,
    speed: Double,
    stage: String,
    player: String,
    opponent: String,
    notes: List<Triple<Double, Int, Double>>,
    events: JSONArray = JSONArray(),
    voices: Boolean = true,
    bpmChanges: List<Pair<Double, Double>> = emptyList(),
    focusChanges: List<Pair<Double, Boolean>> = emptyList(),
    useFocusForSections: Boolean = false,
    noteTypes: Map<Triple<Double, Int, Double>, String> = emptyMap(),
    girlfriend: String = "gf"
): String {
    val safeBpm = bpm.takeIf { it.isFinite() && it > 0 } ?: 100.0
    val sorted = notes.filter { it.first.isFinite() && it.first >= 0 }.sortedBy { it.first }
    val sortedBpm = bpmChanges.filter { it.first.isFinite() && it.second.isFinite() && it.first > 0 && it.second > 0 }.sortedBy { it.first }
    val sortedFocus = focusChanges.filter { it.first.isFinite() && it.first >= 0 }.sortedBy { it.first }
    val maxTime = sorted.maxOfOrNull { it.first } ?: 0.0
    val sections = JSONArray()
    var noteCursor = 0
    var bpmCursor = 0
    var focusCursor = 0
    var activeBpm = safeBpm
    var previousBpm = safeBpm
    var activeFocus = false
    var sectionStart = 0.0
    var sectionIndex = 0
    do {
        // Psych stores tempo per section. Snap an in-section source tempo change to the
        // nearest step boundary and split the section there, rather than delaying it until
        // the next full 16-step section. This keeps notes after the change in the new tempo.
        var stepDuration = 60000.0 / activeBpm / 4.0
        while (bpmCursor < sortedBpm.size && sortedBpm[bpmCursor].first <= sectionStart + stepDuration * 0.5) {
            activeBpm = sortedBpm[bpmCursor].second
            bpmCursor++
            stepDuration = 60000.0 / activeBpm / 4.0
        }
        while (focusCursor < sortedFocus.size && sortedFocus[focusCursor].first <= sectionStart + 1.0) {
            activeFocus = sortedFocus[focusCursor].second
            focusCursor++
        }
        var sectionLengthInSteps = 16
        val nominalSectionEnd = sectionStart + stepDuration * 16.0
        if (bpmCursor < sortedBpm.size) {
            val nextChangeTime = sortedBpm[bpmCursor].first
            if (nextChangeTime > sectionStart + stepDuration * 0.5 &&
                nextChangeTime < nominalSectionEnd - stepDuration * 0.5) {
                sectionLengthInSteps = (((nextChangeTime - sectionStart) / stepDuration).roundToInt())
                    .coerceIn(1, 15)
            }
        }
        val sectionEnd = sectionStart + stepDuration * sectionLengthInSteps
        val sectionNotes = JSONArray()
        var playerNotes = 0
        var opponentNotes = 0
        while (noteCursor < sorted.size && sorted[noteCursor].first < sectionEnd) {
            val note = sorted[noteCursor++]
            val noteArray = JSONArray().put(note.first).put(note.second).put(note.third)
            noteArray.put(noteTypes[note] ?: "")
            sectionNotes.put(noteArray)
            if (note.second >= 4) playerNotes++ else opponentNotes++
        }
        val mustHit = if (useFocusForSections) activeFocus else playerNotes > opponentNotes
        val bpmChanged = kotlin.math.abs(activeBpm - previousBpm) > 0.0001
        sections.put(JSONObject()
            .put("sectionNotes", sectionNotes)
            .put("lengthInSteps", sectionLengthInSteps)
            .put("mustHitSection", mustHit)
            .put("altAnim", false)
            .put("gfSection", false)
            .put("changeBPM", bpmChanged)
            .put("bpm", activeBpm))
        previousBpm = activeBpm
        sectionStart = sectionEnd
        sectionIndex++
    } while ((sectionStart <= maxTime || noteCursor < sorted.size || sectionIndex == 0) && sectionIndex < 10000)

    val songObject = JSONObject()
        .put("song", song)
        .put("notes", sections)
        .put("bpm", safeBpm)
        .put("needsVoices", voices)
        .put("speed", speed)
        .put("player1", player)
        .put("player2", opponent)
        .put("gfVersion", girlfriend)
        .put("stage", stage)
        .put("validScore", true)
    if (events.length() > 0) songObject.put("events", events)
    return JSONObject().put("song", songObject).toString(2)
}
