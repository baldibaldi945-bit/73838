package com.modbridge.core

data class ConversionWarning(val severity: String, val path: String, val message: String)
data class ConversionReport(
    val sourceEngine: String,
    val filesCopied: Int = 0,
    val chartsConverted: Int = 0,
    val warnings: MutableList<ConversionWarning> = mutableListOf(),
    val convertedFiles: MutableList<String> = mutableListOf()
)
