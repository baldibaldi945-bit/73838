package com.modbridge.app

import android.net.Uri
import android.provider.OpenableColumns
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import com.modbridge.core.ArchiveConverter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ModBridgeScreen() }
    }

    @Composable
    private fun ModBridgeScreen() {
        var sourceUri by remember { mutableStateOf<Uri?>(null) }
        var targetUri by remember { mutableStateOf<Uri?>(null) }
        var sourceLabel by remember { mutableStateOf("لم يتم اختيار ملف بعد") }
        var targetLabel by remember { mutableStateOf("لم يتم اختيار مجلد بعد") }
        var status by remember { mutableStateOf("اختر ملف المود ومجلد الإخراج ثم ابدأ التحويل.") }
        var details by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        var includeBackup by remember { mutableStateOf(false) }
        var optimizeShaders by remember { mutableStateOf(true) }
        val scope = rememberCoroutineScope()

        val sourcePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                sourceUri = uri
                sourceLabel = runCatching {
                    contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                        if (cursor.moveToFirst()) cursor.getString(0) else null
                    }
                }.getOrNull() ?: uri.lastPathSegment ?: "تم اختيار ملف"
            }
        }
        val targetPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                targetUri = uri
                targetLabel = uri.lastPathSegment ?: "تم اختيار مجلد"
                runCatching { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            }
        }

        MaterialTheme(colorScheme = darkColorScheme()) {
            Surface(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Image(
                            painter = painterResource(R.drawable.app_icon),
                            contentDescription = "ModBridge application icon",
                            modifier = Modifier.size(88.dp),
                            contentScale = ContentScale.Crop
                        )
                        Column {
                            Text("ModBridge", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                            Text("Offline Mod Converter + Script AI", style = MaterialTheme.typography.bodyMedium)
                            Text("إلى Psych Engine", style = MaterialTheme.typography.titleMedium)
                        }
                    }

                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text("المحوّلات المدمجة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("V-Slice  →  Psych Engine")
                            Text("Codename Engine  →  Psych Engine")
                            Text("Funky Maker Mobile  →  Psych Engine")
                            Text("اكتشاف نوع المود تلقائياً • العمل محلياً دون اتصال")
                        }
                    }

                    Button(
                        onClick = { sourcePicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("اختيار ملف المود (ZIP / FNMM)") }
                    Text(sourceLabel, style = MaterialTheme.typography.bodySmall)

                    OutlinedButton(
                        onClick = { targetPicker.launch(null) },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("اختيار مجلد حفظ المود الناتج") }
                    Text(targetLabel, style = MaterialTheme.typography.bodySmall)

                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("خيارات التحويل", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("باني Spritesheets يعمل تلقائياً عند اكتشاف ملفات FNMM المتحركة.", style = MaterialTheme.typography.bodySmall)
                            SettingCheck("تخفيف الشيدرات وتقليل غير المستخدم منها", optimizeShaders, !busy) { optimizeShaders = it }
                            SettingCheck("إرفاق نسخة احتياطية من ملفات المصدر غير المحوّلة", includeBackup, !busy) { includeBackup = it }
                            Text("عند إيقاف النسخة الاحتياطية، الملفات التي لا تعمل مع Psych تُستبعد من المود النهائي.", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    Button(
                        onClick = {
                            val selectedSource = sourceUri
                            val selectedTarget = targetUri
                            if (selectedSource == null || selectedTarget == null) {
                                status = "اختر ملف المود ومجلد الإخراج أولاً."
                                return@Button
                            }
                            busy = true
                            status = "جاري فحص بنية المود وتحويل محتوياته…"
                            details = ""
                            val backupOption = includeBackup
                            val shaderOption = optimizeShaders
                            val originalName = sourceLabel
                            scope.launch {
                                val operation = withContext(Dispatchers.IO) {
                                    runCatching {
                                        val input = contentResolver.openInputStream(selectedSource)?.use { stream ->
                                            val output = ByteArrayOutputStream()
                                            val buffer = ByteArray(64 * 1024)
                                            var total = 0L
                                            while (true) {
                                                val count = stream.read(buffer)
                                                if (count < 0) break
                                                total += count
                                                require(total <= 1024L * 1024L * 1024L) { "ملف المود أكبر من حد القراءة الآمن (1GB)." }
                                                output.write(buffer, 0, count)
                                            }
                                            output.toByteArray()
                                        } ?: error("تعذرت قراءة الملف المختار.")

                                        val converted = ArchiveConverter.convert(input, backupOption, shaderOption, originalName)
                                        val atlas = AndroidSpriteSheetBuilder.process(converted.bytes)
                                        val finalArchive = atlas.archive
                                        val atlasSummary = "Spritesheets: ${atlas.atlases} • Frames: ${atlas.frames}" +
                                            if (atlas.warnings.isEmpty()) "" else "\n" + atlas.warnings.joinToString("\n")

                                        val tree = DocumentFile.fromTreeUri(this@MainActivity, selectedTarget)
                                            ?: error("مجلد الإخراج غير صالح.")
                                        val safeSource = converted.source.replace(Regex("[^A-Za-z0-9_-]"), "-")
                                        val fileName = "ModBridge-$safeSource-Psych.zip"
                                        tree.findFile(fileName)?.delete()
                                        val resultFile = tree.createFile("application/zip", fileName)
                                            ?: error("لم أستطع إنشاء ملف النتيجة داخل المجلد.")
                                        contentResolver.openOutputStream(resultFile.uri)?.use { it.write(finalArchive) }
                                            ?: error("لم أستطع حفظ ملف ZIP الناتج.")
                                        Triple(converted, atlasSummary, finalArchive.size)
                                    }
                                }
                                operation.onSuccess { (converted, atlasSummary, outputSize) ->
                                    status = "اكتمل التحويل إلى Psych Engine.\nالمصدر: ${converted.source}\nالملفات المفحوصة: ${converted.files}\nالشارتات: ${converted.charts}\nسكربتات AI المترجمة: ${converted.scriptsTranslated}\nحجم ZIP: ${outputSize / 1024} KB"
                                    details = buildString {
                                        if (atlasSummary.isNotBlank()) appendLine(atlasSummary)
                                        appendLine("ملفات المصدر المستبعدة من التشغيل: ${converted.sourceFilesExcluded}")
                                        if (converted.warnings.isEmpty()) appendLine("لم تُسجل ملاحظات بنيوية.")
                                        else converted.warnings.take(60).forEach { appendLine("• $it") }
                                    }
                                }.onFailure { error ->
                                    status = "تعذر إكمال التحويل: ${error.message ?: "خطأ غير معروف"}"
                                    details = "لم يتم إنشاء APK أو تشغيل Psych Engine هنا؛ هذه العملية تنتج ملف مود ZIP متوافقاً قدر الإمكان."
                                }
                                busy = false
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "جاري التحويل…" else "ابدأ التحويل النهائي") }

                    if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text(status, style = MaterialTheme.typography.bodyMedium)
                    if (details.isNotBlank()) {
                        Divider()
                        Text("تقرير التحويل", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(details, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "AI السكربتات يعمل محلياً بقواعد تحويل واضحة، ولا يتصل بالإنترنت أو يخترع شيفرة. المنطق الخاص غير المعروف يُستبعد من التشغيل ويُذكر في التقرير.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }

    @Composable
    private fun SettingCheck(label: String, checked: Boolean, enabled: Boolean, onChanged: (Boolean) -> Unit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = onChanged, enabled = enabled)
            Text(label, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
